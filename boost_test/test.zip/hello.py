import hello
print(hello.greet("good"))